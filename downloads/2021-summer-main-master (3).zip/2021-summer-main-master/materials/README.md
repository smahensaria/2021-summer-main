# Materials

Demo notebooks and other miscellaneous materials.

- [Background materials](prelim/): probability, information theory, linear algebra, 
  gradient descent, and TensorFlow.

*Note that there won't be a demo notebook for every week of the course!*

